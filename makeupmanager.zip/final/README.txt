Features:
- add/delete products
- search for products
- sort products
- filter products by type
- edit properties of products

Changes:
- I got rid of the concept of adding colours to each product
- Can only filter by type not colour or rating + no filter page

Bugs:
- Haven't found any

If I had more time:
- I would try to add animations so the program feels smoother

Comments:
- Was fun to figure out how to connect the product UIs to the product object, and making the search function was fun too
- A part that was not fun was trying to figure out the scrolling/grid layout and how to get the correct number of rows 